import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {
  sub: any;
  id: number;
  serviceData: any;
  serviceDataAddress: any;
  address: any;
  totalAmount: number;
  itemNames: any;
  itemName: any;
  constructor(private route: ActivatedRoute,
    private router: Router, private service: ServiceService, ) { }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
    });

    this.serviceData = this.service.orders[this.id];
    this.serviceDataAddress = this.service.orders[this.id]['Address'];
    this.itemNames = this.service.orders[this.id]['numberOfItems'];
    this.itemNames.forEach(element => {
        this.itemName = element;
        this.totalAmount = this.itemName['cost'] * this.serviceData['numberOfItems'].length;   
    });
    //single addrees
    this.serviceDataAddress.forEach(element => {
      this.address = element;
    });


  }

}
