import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { ServiceService } from '../service.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';


@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {
  serviceData: any;
  sub: any;
  id: number;
  itemNames: any;
  itemName: any;
  totalAmount:any;
  constructor(private fb: FormBuilder, private service: ServiceService, private route: ActivatedRoute,
  private router:Router) { }

  ngOnInit() {
    // gettin id from home page order
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
    });
    this.serviceData = this.service.orders[this.id];
  
    this.itemNames = this.service.orders[this.id]['numberOfItems'];
    this.itemNames.forEach(element => {
        this.itemName = element;
        this.totalAmount = this.itemName['cost'] * this.serviceData['numberOfItems'].length;   
    });
  }

// Order status of order list
  statusUpdate() {
    let id = this.id;
    let status = this.service.orders[this.id]['status'];
    if (status == 'order recived') {
      this.service.orders[this.id]['status'] = "Preparing";
    } else if (status == 'Prepairing') {
      this.service.orders[this.id]['status'] = "Ready TO serve";
    } 
    this.router.navigate(['/item-details', id]);
  }

  // cancel order
  backOrder(){
    this.router.navigate(['/home']);
  }

}
