import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  orders:any;
  constructor() { 
    // Order List Json mock
    this.orders = [
      { id: 0, itemOrder: "order 1", customerName: 'Devi', numberOfItems:[{itemName:'Biryani', cost:100,}], status: 'Prepairing', Address: [{ address_line:'H.No - 3-48/64 MLA residency ', street: 'KRM colony', state: 'AP', pinCode: 500131 }] },
      { id: 1, itemOrder: "order 2", customerName: 'Mani', numberOfItems:[{itemName:'Biryani', cost:70},
      {itemName:'Veg Biryani', cost:70}], status: 'Prepairing', Address: [{ address_line:'H.No - 8-1/32 Kamala Priya residency ', street: 'VIP colony', state: 'AP', pinCode: 500131 }] },
      { id: 2, itemOrder: "order 3", customerName: 'Bittu', numberOfItems:[{itemName:'Biryani', cost:100},
      {itemName:'Biryani', cost:100}], status: 'Prepairing', Address: [{ address_line:'H.No - 3-48/64 MLA residency ', street: 'krmcolony', state: 'AP', pinCode: 500131 }] },
      { id: 3, itemOrder: "order 4", customerName: 'soumaya', numberOfItems:[{itemName:'Biryani', cost:300,},
      {itemName:'Veg Biryani', cost:70}], status: 'Prepairing', Address: [{ address_line:'H.No - 3-48/64 Nanda residency ', street: 'krmcolony', state: 'AP', pinCode: 500131 }] },   
      { id: 4, itemOrder: "order 5", customerName: 'giri', numberOfItems:[{itemName:'Biryani', cost:70},
      {itemName:'Veg Biryani', cost:70}], status: 'Ready to serve', Address: [{ address_line:'H.No - 3-48/64 MLA residency ', street: 'krmcolony', state: 'AP', pinCode: 500131 }] },   
      { id: 5, itemOrder: "order 6", customerName: 'pavani', numberOfItems:[{itemName:'Biryani', cost:70},{itemName:'Veg Biryani', cost:70}], status: 'Ready to serve', Address: [{ address_line:'H.No - 3-48/64 MLA residency ', street: 'krmcolony', state: 'US', pinCode: 500131 }] },   
      { id: 6, itemOrder: "order 7", customerName: 'sai', numberOfItems:[{itemName:'Biryani', cost:70},{itemName:'Veg Biryani', cost:70}], status: 'Ready to serve', Address: [{ address_line:'H.No - 3-48/64 MLA residency ', street: 'krmcolony', state: 'AP', pinCode: 500131 }] },
    ];
  }
}
