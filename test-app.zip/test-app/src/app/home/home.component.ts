import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {ServiceService} from 'src/app/service.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  itemOrders: any;
  orderItems: boolean = false;
  serviceData;
  orderId:number;
  order: any;
  // orders = [
  //   { id: 1, itemOrder: "order1", customerName: 'Devi', numberOfItems: 3, amount: 300, status: 'recived', Address: [{ state: 'AP', street: 'krmcolony', pinCode: 12345 }] },
  //   { id: 2, itemOrder: "order2", customerName: 'Mani', numberOfItems: 2, amount: 200, status: 'pending', Address: [{ state: 'AP', street: 'krmcolony', pinCode: 12345 }] },
  //   { id: 3, itemOrder: "order3", customerName: 'Bittu', numberOfItems: 1, amount: 100, status: 'recived', Address: [{ state: 'AP', street: 'krmcolony', pinCode: 12345 }] },
  // ];
 
  constructor(private router: Router, private service: ServiceService) { }
  display: boolean = false;

  ngOnInit() {
    // Service call mock data
    this.serviceData = this.service.orders;    
  }

  // when click the oder button its route change to order-details page
  accept(order) {
    let id = order['id'];
    console.log(this.itemOrders);
    this.router.navigate(['/order-details', id]);
  }

  // notAccept the order button
  notAccept() {
    alert('not accepted the order')
  }

}
