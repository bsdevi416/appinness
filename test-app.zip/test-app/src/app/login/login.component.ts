import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email:any;
  password:string;
  constructor(private router: Router) { }

  ngOnInit() {

  }

  // Login for home page
  login(){
    if(this.email == "admin@gmail.com" && this.password == "Admin"){
      console.log('sada');
      this.router.navigate(['/home']);
    }else{
      console.log('notlogin')
    }
  }
}
